package com.wellsfargo.batch7.sbwdsif;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebDataSecurityIbsFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
