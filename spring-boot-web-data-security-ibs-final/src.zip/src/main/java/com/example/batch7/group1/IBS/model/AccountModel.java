package com.example.batch7.group1.IBS.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;




public class AccountModel {
	
	
	private CustomerModel UCI;
	   
	@NotNull(message="AcctNumer is mandate")
	@NotBlank(message="AcctNumber is mandate")
	private Integer acctNumber;
	
	@NotNull(message="Accttype is mandate")
	@NotBlank(message="Accttype is mandate")
	private String acctType;

	@NotNull(message="Acctbalance is mandate")
	@NotBlank(message="Acctbalance is mandate")
	private Integer acctBalance;
	
    public AccountModel() {
		
	}



	public AccountModel(CustomerModel uCI,Integer acctNumber,String acctType,Integer acctBalance) {
		super();
		this.acctNumber=acctNumber;
		this.UCI = uCI;
		this.acctType = acctType;
		this.acctBalance = acctBalance;
	}

    

   public CustomerModel getUCI() {
		return UCI;
	}

	public void setUCI(CustomerModel UCI) {
		this.UCI=UCI;
	}

    public Integer getAcctNumber() {
		return acctNumber;
	}

	public void setAcctNumber(Integer acctNumber) {
		this.acctNumber = acctNumber;
	}


	public String getAcctType() {
		return acctType;
	}

	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	public Integer getAcctBalance() {
		return acctBalance;
	}

	public void setAcctBalance(Integer acctBalance) {
		this.acctBalance = acctBalance;
	}
	
	


}
