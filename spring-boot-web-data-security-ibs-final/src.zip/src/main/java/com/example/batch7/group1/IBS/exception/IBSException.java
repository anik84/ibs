package com.example.batch7.group1.IBS.exception;

public class IBSException extends Exception{
	public IBSException(String message)
	{
		super(message);
	}
}
