package com.example.batch7.group1.IBS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegratedBankingSystemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
