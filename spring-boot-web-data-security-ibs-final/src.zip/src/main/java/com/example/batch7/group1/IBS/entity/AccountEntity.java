package com.example.batch7.group1.IBS.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Account")

public class AccountEntity {
	
	@OneToOne
	@JoinColumn(name="uid")
	private CustomerEntity UCI;
	@Id
	private Integer acctNumber;
	@Column(name="Accttype")
	private String acctType;
	@Column(name="AcctBalance")
	private Integer acctBalance;
	
	public AccountEntity() {
		
	}

	public AccountEntity(CustomerEntity uCI, Integer acctNumber,String acctType, Integer acctBalance) {
		super();
		this.UCI = uCI;
		this.acctNumber = acctNumber;
		this.acctType = acctType;
		this.acctBalance = acctBalance;
	}
    
	
	public Integer getAcctNumber() {
		return acctNumber;
	}

	public void setAcctNumber(Integer acctNumber) {
		this.acctNumber = acctNumber;
	}

	public CustomerEntity getUCI() {
		return UCI;
	}

	public void setUCI(CustomerEntity uCI) {
		UCI = uCI;
	}

	public String getAcctType() {
		return acctType;
	}

	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	public Integer getAcctBalance() {
		return acctBalance;
	}

	public void setAcctBalance(Integer acctBalance) {
		this.acctBalance = acctBalance;
	}
	
	

}
