package com.example.batch7.group1.IBS.service;

import java.util.List;

import com.example.batch7.group1.IBS.exception.IBSException;
import com.example.batch7.group1.IBS.model.AccountModel;

public interface AccountService {
	
	AccountModel update(AccountModel account) throws IBSException;
	List<AccountModel> getAll() throws IBSException;
}
