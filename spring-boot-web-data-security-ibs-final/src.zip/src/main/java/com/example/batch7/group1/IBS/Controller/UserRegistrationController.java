package com.example.batch7.group1.IBS.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.batch7.group1.IBS.exception.IBSException;
import com.example.batch7.group1.IBS.model.CustomerModel;
import com.example.batch7.group1.IBS.service.CustomerService;

@Controller
@RequestMapping("/userRegistration")
public class UserRegistrationController {

	@Autowired
	private CustomerService custService;
	
	@Autowired
	private PasswordEncoder encoder;

	@GetMapping("")
	public ModelAndView newContactAction() {
		ModelAndView mv = new ModelAndView("user/user_registration_form", "newUser", new CustomerModel());
		return mv;
	}

	@PostMapping("/register")
	public ModelAndView addContactAction(@ModelAttribute("newUser") @Valid CustomerModel customer, BindingResult result)
			throws IBSException {
		
		ModelAndView mv = null;
		customer.setUserId(null);
		customer.setRole("user");
		customer.setPassword(encoder.encode("anik"));
		//System.out.println(customer.getUserName());
		if (result.hasErrors()) {
			mv = new ModelAndView("user/user_registration_form", "newUser", customer);
		} else {
			custService.register(customer);
			mv = new ModelAndView("redirect:/home");//user/user_registration_form
		}

		return mv;
	}

}
