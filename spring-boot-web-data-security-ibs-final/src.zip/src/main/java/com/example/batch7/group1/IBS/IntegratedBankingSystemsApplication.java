package com.example.batch7.group1.IBS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegratedBankingSystemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegratedBankingSystemsApplication.class, args);
	}

}
