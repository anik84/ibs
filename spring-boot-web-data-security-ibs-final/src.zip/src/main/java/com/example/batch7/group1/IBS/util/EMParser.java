package com.example.batch7.group1.IBS.util;

import com.example.batch7.group1.IBS.entity.AccountEntity;
import com.example.batch7.group1.IBS.entity.CustomerEntity;
import com.example.batch7.group1.IBS.entity.UserEntity;
import com.example.batch7.group1.IBS.model.AccountModel;
import com.example.batch7.group1.IBS.model.CustomerModel;
import com.example.batch7.group1.IBS.model.UserModel;


public class EMParser {
	
	public static CustomerModel parse(CustomerEntity source) {
		CustomerModel target=new CustomerModel();
		//target.setCustId(null);
		target.setUserId(source.getUserId());
		target.setUserName(source.getUserName());
		target.setPassword(source.getPassword());
		target.setRole(source.getRole());
		target.setCustFirstName(source.getCustFirstName());
		target.setCustLastName(source.getCustLastName());
		target.setCustEmail(source.getCustEmail());
		target.setCustAddress(source.getCustAddress());
		target.setCustdob(source.getCustdob());
		target.setCustPhoneNo(source.getCustPhoneNo());
		//target.setRole("customer");
		return target;		
	}

	public static CustomerEntity parse(CustomerModel source) {
		CustomerEntity target=new CustomerEntity();
		//target.set(source.getCustId());
		target.setUserId(source.getUserId());
		target.setUserName(source.getUserName());
		target.setPassword(source.getPassword());
		target.setRole(source.getRole());
		//target.setCustId(source.getCustId());
		target.setCustFirstName(source.getCustFirstName());
		target.setCustLastName(source.getCustLastName());
		target.setCustEmail(source.getCustEmail());
		target.setCustAddress(source.getCustAddress());
		target.setCustdob(source.getCustdob());
		target.setCustPhoneNo(source.getCustPhoneNo());
		return target;		
	}

	public static UserModel uparse(UserEntity source) {
		UserModel target=new UserModel();
		//target.setUserId(source.getUserId());
		target.setUserName(source.getUserName());
		/*target.setPassword(source.getPassword());*/
		target.setRole("customer");
		return target;		
	}
	
	public static UserEntity uparse(UserModel source) {
		UserEntity target=new UserEntity();
		//target.setUserId(source.getUserId());
		target.setUserName(source.getUserName());
		/*target.setPassword(source.getPassword());*/
		target.setRole("customer");
		return target;		
	}


	public static CustomerModel cparse(CustomerEntity source) {
		CustomerModel target=new CustomerModel();
		/*target.setUserId(source.getUserId());
		target.setUserName(source.getUserName());
		target.setPassword(source.getPassword());
		target.setRole(source.getRole());*/
		//target.setCustId(source.getCustId());
		target.setCustUCI(aparse(source.getCustUCI()));
		target.setCustFirstName(source.getCustFirstName());
		target.setCustLastName(source.getCustLastName());
		target.setCustEmail(source.getCustEmail());
		target.setCustAddress(source.getCustAddress());
		target.setCustdob(source.getCustdob());
		target.setCustPhoneNo(source.getCustPhoneNo());
		return target;		
	}

	public static CustomerEntity cparse(CustomerModel source) {
		CustomerEntity target=new CustomerEntity();
		/*target.setUserId(source.getUserId());
		target.setUserName(source.getUserName());
		target.setPassword(source.getPassword());
		target.setRole(source.getRole());*/
		//target.setCustId(source.getCustId());
		target.setCustUCI(aparse(source.getCustUCI()));
		target.setCustFirstName(source.getCustFirstName());
		target.setCustLastName(source.getCustLastName());
		target.setCustEmail(source.getCustEmail());
		target.setCustAddress(source.getCustAddress());
		target.setCustdob(source.getCustdob());
		target.setCustPhoneNo(source.getCustPhoneNo());
		return target;		
	}
    
	public static AccountModel aparse(AccountEntity source) {
		AccountModel target = new AccountModel();
		target.setAcctNumber(source.getAcctNumber());
		target.setAcctType(source.getAcctType());
		target.setAcctBalance(source.getAcctBalance());
		target.setUCI(cparse(source.getUCI()));
		return target;
	}
	
	public static AccountEntity aparse(AccountModel source) {
		AccountEntity target = new AccountEntity();
		target.setAcctNumber(source.getAcctNumber());
		target.setAcctType(source.getAcctType());
		target.setAcctBalance(source.getAcctBalance());
		target.setUCI(cparse(source.getUCI()));
		return target;
	}


	
}
