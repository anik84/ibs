package com.example.batch7.group1.IBS.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.batch7.group1.IBS.exception.IBSException;
import com.example.batch7.group1.IBS.model.AccountModel;
import com.example.batch7.group1.IBS.repo.AccountRepo;
import com.example.batch7.group1.IBS.util.EMParser;

@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	private AccountRepo accountRepo;
	
	@Transactional
	@Override
	public AccountModel update(AccountModel account) throws IBSException {
		// TODO Auto-generated method stub
		if(account!=null) {
			if(!accountRepo.existsById(account.getAcctNumber())) {
				throw new IBSException("Account#"+account.getAcctNumber()+" does not exists");
			}
			account = EMParser.aparse(accountRepo.save(EMParser.aparse(account)));
		}
		return account;
	}

	@Override
	public List<AccountModel> getAll() throws IBSException {
		// TODO Auto-generated method stub
		return accountRepo.findAll().stream().map(e->EMParser.aparse(e)).collect(Collectors.toList());
	}

}
