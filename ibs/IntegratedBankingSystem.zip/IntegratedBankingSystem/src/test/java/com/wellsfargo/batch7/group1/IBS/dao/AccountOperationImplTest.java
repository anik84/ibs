package com.wellsfargo.batch7.group1.IBS.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccountOperationImplTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
