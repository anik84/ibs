package com.example.batch7.group1.IBS.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.batch7.group1.IBS.entity.AccountEntity;


@Repository
public interface AccountRepo extends JpaRepository<AccountEntity,Integer>{
	
	//List<Account> findAllByAdbGroup(Beneficiaries adbGroup);

}
