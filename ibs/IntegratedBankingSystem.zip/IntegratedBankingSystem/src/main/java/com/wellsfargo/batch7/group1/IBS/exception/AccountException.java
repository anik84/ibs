package com.wellsfargo.batch7.group1.IBS.exception;

public class AccountException extends Exception{
	
	/**
	 * 
	 */
	

	public AccountException(String message) {
		super(message);
	}

}
