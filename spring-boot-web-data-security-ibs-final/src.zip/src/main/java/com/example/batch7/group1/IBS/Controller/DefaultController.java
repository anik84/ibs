package com.example.batch7.group1.IBS.Controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class DefaultController {
	
	@RequestMapping(value={"","/","/home"},method=RequestMethod.GET)
	public String homeAction(){
		return "index";
	}
	
	@RequestMapping("/newUser")
	public String newUserAction() {
		return "redirect:userRegistration";
	}
	
	/*
	 * @RequestMapping("/changePwd") public String changePwdAction() { return
	 * "redirect:resetPwd"; }
	 */
	
	/*@GetMapping("/login")
	public String loginAction() {
		String view = "index";

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (!(auth instanceof AnonymousAuthenticationToken) && auth.isAuthenticated()) {
			view = "redirect:/userHome";
		}

		return view;
	}*/
	
}
