package com.example.batch7.group1.IBS.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.batch7.group1.IBS.exception.IBSException;
import com.example.batch7.group1.IBS.model.CustomerModel;
import com.example.batch7.group1.IBS.model.UserModel;
import com.example.batch7.group1.IBS.repo.CustomerRepo;
import com.example.batch7.group1.IBS.repo.UserRepo;
import com.example.batch7.group1.IBS.util.EMParser;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepo customerRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@Transactional
	@Override
	public void register(CustomerModel customer) throws IBSException {
		/*if(customer!=null) {
			if(!customerRepo.existsById(customer.getCustId())) {
				throw new AccountException("Customer#"+customer.getUserId()+" does not exists");
			}*/
		
		//System.out.println(customer.getUserName());
		//userRepo.setUserDetails(customer.getUserName());
			customer = EMParser.parse(customerRepo.save(EMParser.parse(customer)));
		//}
		//return customer;
	}

	@Override
	public List<CustomerModel> getAll() throws IBSException {
		// TODO Auto-generated method stub
		return customerRepo.findAll().stream().map(e->EMParser.parse(e)).collect(Collectors.toList());
	}

	

}
