package com.example.batch7.group1.IBS.service;

import java.util.List;

import com.example.batch7.group1.IBS.exception.IBSException;
import com.example.batch7.group1.IBS.model.CustomerModel;
import com.example.batch7.group1.IBS.model.UserModel;

public interface CustomerService {
	
	void register(CustomerModel customer) throws IBSException;
	List<CustomerModel> getAll() throws IBSException;

}
