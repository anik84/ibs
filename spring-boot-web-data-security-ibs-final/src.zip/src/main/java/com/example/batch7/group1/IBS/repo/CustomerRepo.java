package com.example.batch7.group1.IBS.repo;

import org.springframework.data.jpa.repository.JpaRepository;



import com.example.batch7.group1.IBS.entity.CustomerEntity;



public interface CustomerRepo extends JpaRepository<CustomerEntity,Integer>{

}
